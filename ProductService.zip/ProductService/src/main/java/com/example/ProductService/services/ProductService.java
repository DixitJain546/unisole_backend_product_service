package com.example.ProductService.services;

import com.example.ProductService.entity.Product;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public interface ProductService {
 public byte[] savefile(MultipartFile file) throws IOException;
    List<Product> getAllProduct();
     List<Product> getAllProductByCategory(String category);
     Optional<Product> getProductById(String id);

 Product getProductByName(String name);
     List<Product> getAllProductsByName(String name);
     Product addProduct(Product product);
     void deleteProduct(String productId);

}
