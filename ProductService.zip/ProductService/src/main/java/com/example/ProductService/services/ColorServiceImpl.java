package com.example.ProductService.services;

import com.example.ProductService.entity.Color;
import com.example.ProductService.repository.ColorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ColorServiceImpl implements ColorService {
    @Autowired
    ColorRepository colorRepository;
    @Override
    public Optional<Color> findById(int id) {
        return colorRepository.findById(id);
    }
}
