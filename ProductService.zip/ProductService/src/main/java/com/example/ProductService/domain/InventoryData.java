package com.example.ProductService.domain;

import com.example.ProductService.entity.Inventory;
import com.example.ProductService.entity.Product;

public class InventoryData {
   // product_name,price,product_rating,merchant_id,product_description,quantity

    private String product_name;
    private int price;
    private int product_rating;
    private  String merchant_id;
    private String product_description;
    private int quantity;

    public InventoryData(String product_name, int price, int product_rating, String merchant_id, String product_description, int quantity) {
        this.product_name = product_name;
        this.price = price;
        this.product_rating = product_rating;
        this.merchant_id = merchant_id;
        this.product_description = product_description;
        this.quantity = quantity;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getProduct_rating() {
        return product_rating;
    }

    public void setProduct_rating(int product_rating) {
        this.product_rating = product_rating;
    }

    public String getMerchant_id() {
        return merchant_id;
    }

    public void setMerchant_id(String merchant_id) {
        this.merchant_id = merchant_id;
    }

    public String getProduct_description() {
        return product_description;
    }

    public void setProduct_description(String product_description) {
        this.product_description = product_description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
