package com.example.ProductService.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import javax.persistence.*;
import java.io.Serializable;

@Embeddable
public class InventoryPK implements Serializable {

    public InventoryPK() {
    }

    @ManyToOne(fetch = FetchType.EAGER)


//    @JsonProperty("product_id")
    @JoinColumn(name="product_id")
    private Product product;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="size_id")
    private Size size;




    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public InventoryPK(Product product, Size size, Color color, String merchantId) {

        this.product = product;
        this.size = size;
        this.color = color;
        this.merchantId = merchantId;
    }

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="color_id")
    private Color color;

    private String merchantId;



    public Size getSize() {
        return size;
    }

    public void setSize(Size size) {
        this.size = size;
    }



    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

}
