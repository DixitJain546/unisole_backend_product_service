package com.example.ProductService.repository;

import com.example.ProductService.domain.InventoryData;
import com.example.ProductService.entity.Color;
import com.example.ProductService.entity.Inventory;
import com.example.ProductService.entity.InventoryPK;
import com.example.ProductService.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
public interface InventoryRepository extends JpaRepository<Inventory,InventoryPK> {


    List<Inventory> findAllByInventoryPKMerchantId(String merchant_id);
    List<Inventory> findAllByInventoryPKProductAndInventoryPKMerchantId(Product p, String merchant_id);
    List<Inventory> findAllByInventoryPKProductAndInventoryPKColorAndInventoryPKMerchantId(Product p, Color c, String merchant_id);
    @Transactional
    @Modifying
    void deleteById(InventoryPK inventoryPK);



    @Transactional
    @Query(value="select count(product_id) from inventory where merchant_id=:merchant_id group by merchant_id ",nativeQuery = true)
    int findCountOfProductByMerhcant_id(@Param("merchant_id") String merchant);

    @Transactional
    @Query(value="select sum(quantity) from inventory where merchant_id=:merchant_id and product_id=:product_id group by merchant_id,product_id ",nativeQuery = true)
    int findStockOfProductByMerhcant_id(@Param("merchant_id") String merchant,@Param("product_id") String product);



}
