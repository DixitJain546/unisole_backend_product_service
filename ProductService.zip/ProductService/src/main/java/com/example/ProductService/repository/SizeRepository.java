package com.example.ProductService.repository;

import com.example.ProductService.entity.Size;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SizeRepository extends JpaRepository<Size,Integer> {
}
