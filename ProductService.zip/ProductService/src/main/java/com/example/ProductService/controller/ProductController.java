package com.example.ProductService.controller;

import com.example.ProductService.entity.Category;
import com.example.ProductService.entity.Product;
import com.example.ProductService.repository.CategoryRepository;
import com.example.ProductService.repository.ProductRepository;
import com.example.ProductService.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/products/")
public class ProductController {

    @Autowired
    ProductService productService;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    CategoryRepository categoryRepository;

    @GetMapping("/category/{category}")
    public ResponseEntity getAllProductByCategory(@PathVariable("category") String category)
    {
            try
            {
                System.out.println("Called");
                 return new ResponseEntity(productService.getAllProductByCategory(category),HttpStatus.OK);
            }
            catch (Exception e)
            {
                return new ResponseEntity(e.getMessage().toString(),HttpStatus.BAD_REQUEST);
            }
    }
    @GetMapping("/name/{productname}")
    public ResponseEntity getAllProductByName(@PathVariable("productname") String productName)
    {
        try
        {
            return new ResponseEntity(productService.getAllProductsByName(productName),HttpStatus.OK);
        }
        catch (Exception e)
        {
            return new ResponseEntity(e.getMessage().toString(),HttpStatus.BAD_REQUEST);
        }
    }
    @GetMapping("/{productid}")
    public ResponseEntity getProductByProductId(@PathVariable("productid") String productid)
    {
        try
        {
            return new ResponseEntity(productService.getProductById(productid),HttpStatus.OK);
        }
        catch (Exception e)
        {
            return new ResponseEntity(e.getMessage().toString(),HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/add")
    public ResponseEntity create(@RequestParam("file") MultipartFile file)
    {
        try{
//        {
//            Product p=new Product();
//            p.setProductId("n2n");
//            p.setProductColor("red");
//            p.setProductDescription("dd");
//            p.setProductRating(9);
//            p.setProductSize(9);
//            p.setProductName("shoes");
//            Category c1=new Category();
//            c1.setCategoryId("c2");
//            categoryRepository.save(c1);
//            p.setCategory(c1);
//            p.setProductImage(productService.savefile(file));
//            return new ResponseEntity(productService.addProduct(p),HttpStatus.OK);
            return new ResponseEntity("",HttpStatus.OK);
        }
        catch (Exception e)
        {
            return new ResponseEntity(e.getMessage().toString(),HttpStatus.BAD_REQUEST);
        }
    }


}
