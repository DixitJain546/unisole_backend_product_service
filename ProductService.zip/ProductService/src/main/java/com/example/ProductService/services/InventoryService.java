package com.example.ProductService.services;

import com.example.ProductService.domain.InventoryData;
import com.example.ProductService.entity.Inventory;
import com.example.ProductService.entity.InventoryPK;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface InventoryService {

     byte[] savefile(MultipartFile file) throws IOException;
     Inventory addStock(Inventory inventory);
     List<Inventory> getStockByMerchantId(String merchantId);
    List<Inventory> getStockByProductAndMerchantId(String productId,String merchantId);
    List<Inventory> getStockByProductAndMerchantIdAndColorId(String productId,String merchantId,int colorId);
    void deleteStock(String productid,String merchantid,int colorid,int sizeid);
    Inventory updateStock(Inventory inventory);
    int getTotalProductsOfferByMerchant(String merchant_id);
    int getQuantityByMerchantIdAndProductId(String merchantId,String productId);


}
