package com.example.ProductService.services;

import com.example.ProductService.entity.Size;

import java.util.Optional;

public interface SizeService {

    Optional<Size> findById(int id);
}
