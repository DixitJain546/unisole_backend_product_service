package com.example.ProductService.services;

import com.example.ProductService.entity.Color;

import java.util.Optional;

public interface ColorService {
    Optional<Color> findById(int id);
}
