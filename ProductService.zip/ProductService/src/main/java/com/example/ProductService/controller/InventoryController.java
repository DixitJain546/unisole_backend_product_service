package com.example.ProductService.controller;

import com.example.ProductService.entity.Inventory;
import com.example.ProductService.entity.InventoryPK;
import com.example.ProductService.entity.Product;
import com.example.ProductService.services.InventoryService;
import com.example.ProductService.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/inventory")
public class InventoryController {
    @Autowired
    InventoryService inventoryService;
    @Autowired
    ProductService productService;
    @GetMapping("/{merchantid}")
    public ResponseEntity getByMerchantId(@PathVariable("merchantid") String merchantId)
    {
        try
        {
            return new ResponseEntity(inventoryService.getStockByMerchantId(merchantId),HttpStatus.OK);
        }
        catch (Exception e)
        {
            return new ResponseEntity(e.getMessage().toString(),HttpStatus.BAD_REQUEST);
        }
    }
    @GetMapping("/{productid}/{merchantid}")
    public ResponseEntity getByProductMerchantId(@PathVariable("productid") String productid,@PathVariable("merchantid") String merchantid)
    {
        try
        {
            System.out.println("called");
            return new ResponseEntity(inventoryService.getStockByProductAndMerchantId(productid,merchantid),HttpStatus.OK);
        }
        catch (Exception e)
        {
            return new ResponseEntity(e.getMessage().toString(),HttpStatus.BAD_REQUEST);
        }
    }
    @GetMapping("/{productid}/{merchantid}/{colorid}")
    public ResponseEntity getByProductMerchantIdColorId(@PathVariable("productid") String productid,@PathVariable("merchantid") String merchantid,@PathVariable("colorid") int colorid)
    {
        try
        {
            System.out.println("called");
            return new ResponseEntity(inventoryService.getStockByProductAndMerchantIdAndColorId(productid, merchantid, colorid),HttpStatus.OK);
        }
        catch (Exception e)
        {
            return new ResponseEntity(e.getMessage().toString(),HttpStatus.BAD_REQUEST);
        }
    }
    @DeleteMapping("/remove/{productid}/{merchantid}/{colorid}/{sizeid}")
    public ResponseEntity deleteInventoryByKey(@PathVariable("productid") String product,@PathVariable("merchantid") String merchantid,@PathVariable("colorid") int colorid,@PathVariable("sizeid") int sizeid)
    {
        try {
            inventoryService.deleteStock(product, merchantid, colorid, sizeid);
            return new ResponseEntity<>("Product Deleted Successfully",HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }
    @PutMapping("/update")
    public ResponseEntity updateInventory(@RequestBody Inventory inventory)
    {
        try {
            return new ResponseEntity<>(inventoryService.updateStock(inventory),HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }
    @PostMapping("/add")
    public ResponseEntity addInventory(@RequestBody Inventory inventory)
    {
        try {
            if(productService.getProductByName(inventory.getInventoryPK().getProduct().getProductName())==null)
            {
                System.out.println("called");
                Product product=new Product();
                product.setProductId(UUID.randomUUID().toString().substring(0, 32));
                product.setProductName(inventory.getInventoryPK().getProduct().getProductName());
                product.setCategory(inventory.getInventoryPK().getProduct().getCategory());
                product.setProductRating(inventory.getInventoryPK().getProduct().getProductRating());
                productService.addProduct(product);
                inventory.getInventoryPK().setProduct(product);
            }
            else
            {
                Product product=productService.getProductByName(inventory.getInventoryPK().getProduct().getProductName());
                inventory.getInventoryPK().setProduct(product);
            }
            return new ResponseEntity<>(inventoryService.addStock(inventory),HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/count/{merchant_id}")
    public ResponseEntity getCountOfProductByMerchantId(@PathVariable("merchant_id") String merchant_id)
    {
        try
        {
            return new ResponseEntity(inventoryService.getTotalProductsOfferByMerchant(merchant_id),HttpStatus.OK);
        }
        catch (Exception e)
        {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/stock/{merchant_id}/{product_id}")
    public ResponseEntity getQuantityOfProductByMerchantId(@PathVariable("merchant_id") String merchant_id,@PathVariable("product_id") String product_id)
    {
        try
        {
            return new ResponseEntity(inventoryService.getQuantityByMerchantIdAndProductId(merchant_id, product_id),HttpStatus.OK);
        }
        catch (Exception e)
        {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }













//    @PostMapping("/add")
//    public ResponseEntity create(@RequestParam("file") MultipartFile file)
//    {
//        try{
////        {
////            Product p=new Product();
////            p.setProductId("n2n");
////            p.setProductColor("red");
////            p.setProductDescription("dd");
////            p.setProductRating(9);
////            p.setProductSize(9);
////            p.setProductName("shoes");
////            Category c1=new Category();
////            c1.setCategoryId("c2");
////            categoryRepository.save(c1);
////            p.setCategory(c1);
////            p.setProductImage(productService.savefile(file));
////            return new ResponseEntity(productService.addProduct(p),HttpStatus.OK);
//            return new ResponseEntity("",HttpStatus.OK);
//        }
//        catch (Exception e)
//        {
//            return new ResponseEntity(e.getMessage().toString(),HttpStatus.BAD_REQUEST);
//        }
//    }
}
