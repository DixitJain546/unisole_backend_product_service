package com.example.ProductService.services;

import com.example.ProductService.domain.InventoryData;
import com.example.ProductService.entity.*;
import com.example.ProductService.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Transactional
@Service
public class InventoryServiceImpl implements  InventoryService {
    @Autowired
    InventoryRepository inventoryRepository;
    @Autowired
    ProductService productService;
    @Autowired
    ColorService colorService;
    @Autowired
    SizeService sizeService;
    @Override
    public byte[] savefile(MultipartFile file) throws IOException {
        return file.getBytes();
    }

    @Override
    public Inventory addStock(Inventory inventory) {
        return inventoryRepository.save(inventory);
    }

    @Override
    public List<Inventory> getStockByMerchantId(String merchantId) {
        return inventoryRepository.findAllByInventoryPKMerchantId(merchantId);
    }

    @Override
    public List<Inventory> getStockByProductAndMerchantId(String productId, String merchantId) {
        System.out.println("called 2");
        Product p=productService.getProductById(productId).get();
        return inventoryRepository.findAllByInventoryPKProductAndInventoryPKMerchantId(p,merchantId);
    }

    @Override
    public List<Inventory> getStockByProductAndMerchantIdAndColorId(String productId, String merchantId, int colorId) {

        Product p=productService.getProductById(productId).get();
        Color c=colorService.findById(colorId).get();
        return inventoryRepository.findAllByInventoryPKProductAndInventoryPKColorAndInventoryPKMerchantId(p,c,merchantId);
    }

    @Override
    public void deleteStock(String productid, String merchantid, int colorid, int sizeid) {
        Product product=productService.getProductById(productid).get();
        Color color=colorService.findById(colorid).get();
        Size size=sizeService.findById(sizeid).get();
        inventoryRepository.deleteById(new InventoryPK(product,size,color,merchantid));
    }


    @Override
    public Inventory updateStock(Inventory inventory) {
        return inventoryRepository.save(inventory);
    }

    @Override
    public int getTotalProductsOfferByMerchant(String merchant_id) {
        return inventoryRepository.findCountOfProductByMerhcant_id(merchant_id);
    }

    @Override
    public int getQuantityByMerchantIdAndProductId(String merchantId, String productId) {
        return inventoryRepository.findStockOfProductByMerhcant_id(merchantId,productId);
    }
}
