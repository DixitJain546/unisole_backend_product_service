package com.example.ProductService.services;

import com.example.ProductService.entity.Size;
import com.example.ProductService.repository.SizeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SizeServiceImpl implements SizeService {
    @Autowired
    SizeRepository sizeRepository;
    @Override
    public Optional<Size> findById(int id) {
        return sizeRepository.findById(id);
    }
}
